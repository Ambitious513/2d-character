# Docs site implementation plan — live `<Player>` examples

**Status:** plan pushed before implementation. Resume from this file if a session ends early.
**Scope:** only the docs site with live Remotion `<Player>` examples. No weather, no npm publish, no v1 shim removal, no rig/composition rendering changes.
**Target repo:** `Ambitious513/2d-character`, branch `main`.

---

## 0. Live stage status — read this first

**Update this table in the same commit that finishes a stage.** Every stage is
pushed on its own; nothing is held back until the end.

| Stage | Scope | State | Commit on `main` |
| --- | --- | --- | --- |
| 0 | Plan pushed before any implementation code | ✅ done | `43d5e9a` |
| 1 | Hash routing, docs shell + scrollspy, hero, quickstart, export, architecture, footer, studio Docs link. `DocsPlayer`, `CodeBlock`, `snippets.ts`, `parts.tsx`, `docs.css` landed here because the hero is a live Player. | ✅ done & pushed | this commit |
| 2 | Playground: permanently visible control region, scene/alpha switch, reset / randomize / copy props / preset download, live snippet | ⬜ next | — |
| 3 | Composition explorer, cast & motion explorer, scene explorer, preset panel | ⬜ | — |
| 4 | `scripts/docs-smoke.mjs`, `smoke:docs`, CI step, packaging guard, README / PROGRESS / ROADMAP / ARCHITECTURE, kit ZIP refresh | ⬜ | — |

### What Stage 1 actually shipped

- `src/main.tsx` — hash router: `/` and `#/studio` render the studio, `#/docs*`
  lazily loads `src/docs/DocsSite.tsx` (separate ~118 kB chunk).
- `src/docs/DocsSite.tsx` — fixed topbar, numbered nav with scrollspy
  (`IntersectionObserver`), deep links `#/docs/<section>`, hero, quickstart,
  export, architecture, footer, toast host (`role="status"`).
- `src/docs/DocsPlayer.tsx` — real `<Player>` + Stride transport (restart,
  play/pause, scrubber, frame readout), error fallback, reduced-motion autoplay
  opt-out, `numberOfSharedAudioTags={0}`.
- `src/docs/CodeBlock.tsx`, `src/docs/snippets.ts`, `src/docs/parts.tsx`,
  `src/docs/docs.css`.
- `src/App.tsx` + `src/styles.css` — a Docs link in the studio topbar only.

Verified for Stage 1: `npm run typecheck`, `npm test` (81/81), `npm run build`,
`npm run smoke` (existing studio, desktop + mobile) all green locally, plus a
manual Playwright pass on `#/docs`: hero Player autoplays and pauses, nav deep
links + scrollspy work, copy toast fires, back-to-studio works, mobile 390×844
has zero horizontal overflow and no console/page errors.

**Resume rule:** continue at the first ⬜ row. Do not re-do a ✅ row.

---

## 1. Goal

Ship a polished, production-ready documentation site inside the existing Vite app that:

- Explains Stride quickly: what it is, how to consume it, how to render/export it.
- Shows real, running Remotion `<Player>` examples, not static mockups.
- Lets a visitor steer a character live through a permanently visible playground control region.
- Demonstrates the public API from `src/index.ts`: compositions, cast, presets, schema, factories, and export recipes.
- Keeps the existing studio at `/` working and CI-green.
- Is responsive, accessible, and visually consistent with Stride's art direction.

## 2. Non-goals

- Do not implement weather (`rain`, `snow`, `fog`).
- Do not publish to npm or change package privacy/versioning.
- Do not remove v1 compatibility shims.
- Do not change the deterministic render path, `stableId`, gait math, or golden hashes unless a docs bug forces it.
- Do not replace the existing studio or break `scripts/smoke.mjs`.

## 3. Technical approach

Use the existing proven stack:

- Vite + React 19 + TypeScript.
- `@remotion/player`, already installed.
- Existing Stride palette, fonts, and SVG rig.
- No new runtime dependencies.

Routing:

- Keep the studio at the root route.
- Add a hash route: `#/docs` and `#/docs/<section>`.
- `src/main.tsx` renders the existing `App` for normal routes and lazily loads `DocsSite` for `#/docs*`.
- Hash routing avoids server rewrite requirements and works in dev, preview, static hosting, and the sandbox preview.

Layering:

- Docs UI lives in `src/docs/`.
- Docs UI is an app consumer, like `src/ui/`.
- Docs UI must not be exported from `src/index.ts`.
- Docs examples should import the public barrel where practical to prove the consumer surface.

## 4. File plan

New files:

- `src/docs/DocsSite.tsx` — docs shell, fixed nav, scrollspy, sections, footer.
- `src/docs/DocsPlayer.tsx` — reusable live `<Player>` wrapper with custom transport, frame readout, error fallback, reduced-motion handling.
- `src/docs/Playground.tsx` — live interactive playground with permanently visible controls, reset/randomize/export.
- `src/docs/CompositionExplorer.tsx` — tabbed live examples: `WalkScene`, `CharacterOnly`, `SceneOnly`, `DialogueScene`, `TalkingHead`.
- `src/docs/CastMotionExplorer.tsx` — tabbed live sheet examples: `CastSheet`, `MotionSheet`, `EmotionSheet`, plus cast cards.
- `src/docs/SceneExplorer.tsx` — live `SceneOnly` with scene/lighting/parallax controls.
- `src/docs/PresetPanel.tsx` — built-in preset cards plus JSON import/validation using `parsePreset`.
- `src/docs/CodeBlock.tsx` — copyable code block with copied state.
- `src/docs/snippets.ts` — pure snippet generators for React usage, composition registration, export commands, and playground props.
- `src/docs/docs.css` — docs-specific visual system, responsive layout, custom scrollbars, motion, layered backgrounds.
- `scripts/docs-smoke.mjs` — Playwright smoke test for the docs route.
- `docs/DOCS_SITE_PLAN.md` — this plan.

Modified files:

- `src/main.tsx` — hash route switch + lazy docs chunk.
- `src/App.tsx` — add a Docs link to the studio topbar without changing studio behavior.
- `src/styles.css` — only minimal shared nav/link styling if needed.
- `package.json` — add `smoke:docs` script.
- `.github/workflows/ci.yml` — run docs smoke in the browser smoke job or a docs smoke step.
- `tests/packaging.test.tsx` — assert docs UI does not leak into the public barrel.
- `README.md` — document the docs route and `smoke:docs`.
- `PROGRESS.md` — record docs site completion and verification.
- `docs/ROADMAP.md` — mark docs site done; weather remains open.
- `docs/ARCHITECTURE.md` — add docs layer and docs smoke coverage.
- `public/stride-remotion-kit.zip` — regenerate after docs source lands.

## 5. Information architecture

Fixed docs navigation:

- Overview
- Quickstart
- Playground
- Compositions
- Cast & motion
- Scenes
- Presets
- Export
- Architecture

Primary actions:

- Open playground.
- Back to studio.
- GitHub repo link.
- Download kit ZIP from export section.

Sections:

### Overview / hero

- Strong first view: live `WalkScene` Player, headline, short value proposition, version/stat chips.
- Stats: 6 cast, 10 motions, 7 emotions, 4 scenes × 3 lighting passes, deterministic SVG.
- Layered background, subtle grain/gradient, motion ticker if it does not distract.
- CTA buttons: Playground, Quickstart, GitHub.

### Quickstart

- Copy-in consumption.
- Register a composition manually.
- Use factories.
- Render commands.
- Copyable snippets.

### Playground

- Live Player, switchable between scene and transparent character plate.
- Permanently visible control region, not hidden in a modal.
- At least these live controls:
  - character select
  - motion select
  - emotion select
  - scene select
  - time-of-day segmented control
  - speed slider
  - stride slider
  - bounce slider
  - arm-swing slider
  - scale slider
  - parallax slider
  - direction toggle
  - follow-camera switch
  - guides switch
  - subtitles switch
  - dialogue input when relevant
  - jacket/pants color pickers
- Reset, randomize, copy props, download preset JSON.
- Live code snippet reflecting current settings.
- Toast feedback for copy/export/reset/randomize/preset load.

### Compositions

- Tabbed live explorer:
  - `WalkScene`
  - `CharacterOnly` on checkerboard
  - `SceneOnly`
  - `DialogueScene` with derived duration
  - `TalkingHead`
- Each tab has description, prop chips, copyable snippet, and a real Player.
- Dialogue example uses `resolveDialogueComposition` so duration covers the script.

### Cast & motion

- Cast cards from `listCharacters()` with head preview, palette swatches, build/outfit metadata.
- Tabbed live sheets:
  - `CastSheet`
  - `MotionSheet`
  - `EmotionSheet`
- Character selector where the sheet supports it.

### Scenes

- Live `SceneOnly` Player.
- Controls for `street`, `park`, `room`, `backdrop`.
- Controls for `day`, `golden`, `night`.
- Parallax slider.
- Copyable snippet reflecting current scene settings.

### Presets

- All built-in presets from `PRESETS`.
- Load into playground and scroll to playground.
- JSON import textarea using `parsePreset`.
- Show validation errors and migration notes.
- Download current playground preset.

### Export

- PNG sequence, ProRes 4444, VP9 WebM, opaque MP4 recipes.
- Alpha/JPEG gotcha callout.
- Copyable commands.
- Download project ZIP link.
- Clarify CI verifies PNG sequence smoke, not finished ProRes/WebM files.

### Architecture

- Determinism rule.
- `stableId` vs `useId`.
- Public barrel boundary.
- Preset schema/versioning.
- Test/CI coverage summary.

## 6. Visual direction

- Subject-specific palette derived from Stride: warm paper, deep ink/forest, saturated orange, electric blue, butter/amber, sage, semantic success/danger.
- Docs should feel like an animation lab field guide: frame rulers, slate chips, palette swatches, layered gradients, subtle grain.
- Fixed topbar with current-section state.
- Anchor jumps land below the fixed nav using `scroll-margin-top`.
- Custom scrollbars matching the palette.
- Staged entrance reveals and hover feedback, but respect `prefers-reduced-motion`.
- No sound; this is a docs/product site, not a game or immersive audio experience.
- Readable contrast on all controls and code blocks.

## 7. Player behavior

- Reusable `DocsPlayer` wrapper:
  - `acknowledgeRemotionLicense`
  - `numberOfSharedAudioTags={0}`
  - custom play/pause, restart, scrubber, frame readout
  - loop where appropriate
  - error fallback
  - deterministic `inputProps`
- Hero and playground may autoplay; secondary examples start paused and can be played.
- Respect reduced motion by disabling autoplay.
- Avoid excessive simultaneous autoplaying Players.
- Do not introduce non-determinism into compositions; UI randomization is allowed only in docs/studio state, not render math.

## 8. Accessibility and responsive behavior

- Label all sliders/selects/switches.
- Keyboard-operable controls and visible focus states.
- `aria-pressed` for segmented toggles.
- Toasts use `role="status"`.
- Mobile: no horizontal overflow; nav remains reachable; playground controls stack below the Player; code blocks scroll internally.
- Test at desktop 1440×960 and mobile 390×844.

## 9. Testing and CI

Local gates:

- `npm run typecheck`
- `npm test`
- `npm run build`
- `npm run verify`
- `npm run smoke` (existing studio)
- `npm run smoke:docs` (new docs route)
- `npm run kit:zip`

Docs smoke should verify:

- Docs route renders without console/page errors.
- Hero Player mounts.
- Playground controls update the live Player.
- Reset/randomize/export actions work.
- Composition tabs switch and Player remains mounted.
- Dialogue example mounts with derived duration.
- Scene controls update scene/lighting attributes.
- Preset load and JSON validation work.
- Mobile docs route has no horizontal overflow and controls are reachable.
- Screenshots are written for review.

CI:

- Keep existing `verify`, `browser-smoke`, and `render-smoke` jobs.
- Add docs smoke to the browser smoke job after studio smoke, or as a separate step using the same dev server.
- Upload docs screenshots with existing screenshots artifact.

## 10. Implementation stages

### Stage 0 — plan pushed first

- Commit and push this plan before writing implementation code.
- Verify remote commit exists.

### Stage 1 — docs shell and routing

- Add hash route and lazy docs chunk.
- Add docs shell, fixed nav, scrollspy, hero, quickstart, footer.
- Add Docs link from studio.
- Verify studio still builds and existing smoke still passes.

### Stage 2 — live Player infrastructure and playground

- Add `DocsPlayer`, `CodeBlock`, snippets.
- Add full playground with live controls and export.
- Verify typecheck/build and manual/browser interaction.

### Stage 3 — example explorers and content sections

- Add composition explorer, cast/motion explorer, scene explorer, preset panel, export, architecture.
- Verify all Players mount and controls update.

### Stage 4 — tests, CI, docs handoff, kit ZIP

- Add docs smoke script and CI step.
- Update packaging guard, README, PROGRESS, ROADMAP, ARCHITECTURE.
- Regenerate kit ZIP.
- Run full local verification and browser smokes.
- Push implementation commit(s).
- Verify GitHub CI is green before announcing completion.

## 11. Acceptance criteria

- `#/docs` opens a complete docs site with live `<Player>` examples.
- The playground has a permanently visible control region with many live adjustments and reset/randomize/export.
- All prominent controls work and update the Player or code snippets immediately.
- Existing studio at `/` still passes its smoke test.
- No public barrel leak of docs UI.
- No weather or unrelated roadmap work is implemented.
- Desktop and mobile docs layouts have no runtime errors, broken states, clipping, or unreachable controls.
- `npm run verify` passes.
- Docs smoke passes locally and in CI.
- Kit ZIP is refreshed.
- Handoff docs accurately describe the new state.
- Final implementation is pushed to GitHub and CI is green before completion is announced.

## 12. Resume instructions

If a later session picks this up:

1. Read `PROGRESS.md`, this plan, and `git log`.
2. Check whether `src/docs/` exists and which stages are already pushed.
3. Continue from the first incomplete stage.
4. Do not redo completed Phase 5 items or start weather.
5. Run `npm run verify`, `npm run smoke`, and `npm run smoke:docs` before pushing.
6. Regenerate `public/stride-remotion-kit.zip` after source/docs changes.
7. Push real source, never a tarball.
8. Verify remote `main` and CI before saying the docs site is complete.
